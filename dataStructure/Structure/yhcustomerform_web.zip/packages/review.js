export default {
  name: 'render',
  props: {},
  created() {
    console.log('监听')
  },
  methods: {

  },
  // render(h) {
  //   console.log('render', this.option)

  //   return h(
  //     <div>
  //       <avueForm ref="form" class="preview-form" option={this.option} value={this.form} ></avueForm>
  //     </div>
  //   )
  // }

  render(h) {
    // console.log('render', this.option)
    // console.log('render value', this.value)
    console.log('render this', this, this.$attrs)
    return h('div', {
        style: {},
        on: {
          onload: function (e) {
            console.log('this.option', e)
          },
          submit() {
            console.log('submit')
          }
        },

      },
      [
        h(
          'avue-form', {
            props: this.$attrs,
            on: {
              submit(form, done) {
                if (done) {

                  console.log('this', this)
                  // this.$alert(form).then(() => {
                  //   done()
                  // }).catch(() => {
                  done()
                  // })
                } else {
                  // this.$refs.form.validate((valid, done) => {
                  //   if (valid) this.$alert(this.form).then(() => {
                  //     done()
                  //   }).catch(() => {
                  //     done()
                  //   })
                  // })
                }
              }
            }
          }
        )
      ]
    )
    // return h('div', <avue-form ref="form" class="preview-form" :option="option" v-model="form" @submit="handlePreviewSubmit"/>)
  }
}