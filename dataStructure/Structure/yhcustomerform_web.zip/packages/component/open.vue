<template>
  <div>
    <p style="line-height: 40px;">lfange config-eventgetComponent</p>
  </div>
</template>

<script>
export default {
  name: 'open'

}
</script>

<style>
</style>