<template>
  <div class="modeler">
    <div id="canvas" class="canvas" ref="canvas"></div>
    <div id="properties"></div>
  </div>
</template>
<script>
// import BpmnViewer from 'bpmn-js'
import Modeler from 'bpmn-js/lib/Modeler'

import 'bpmn-js/dist/assets/diagram-js.css' // 左边工具栏以及编辑节点的样式
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-codes.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css'

import 'bpmn-js-properties-panel/dist/assets/properties-panel.css' // 右边工具栏样式
import 'bpmn-js-properties-panel/dist/assets/element-templates.css' // 右边工具栏样式


// import {
// BpmnPropertiesPanelModule,
// BpmnPropertiesProviderModule,
// use Camunda Platform properties provider
//   CamundaPlatformPropertiesProviderModule
// } from 'bpmn-js-properties-panel';


// use Camunda BPMN Moddle extension
// import CamundaExtensionModule from 'camunda-bpmn-moddle/lib';

// use Camunda BPMN namespace
// import camundaModdleDescriptors from 'camunda-bpmn-moddle/resources/camunda';

import Diagram from './newDiagram'
export default {
  data () {
    return {
      bpmnModeler: null
    }
  },
  mounted () {
    this.init()
  },
  methods: {
    init () {
      // 获取到属性ref为“canvas”的dom节点
      // const canvas = this.$refs.canvas
      // 建模
      this.bpmnModeler = new Modeler({
        container: '#canvas',
        //添加控制板
        propertiesPanel: {
          // parent: '#js-properties-panel'
          // parent: '#properties'
        },
        additionalModules: [
          //   // 右边的属性栏
          // BpmnPropertiesPanelModule,
          // BpmnPropertiesProviderModule,
          //   CamundaPlatformPropertiesProviderModule,
          //   CamundaExtensionModule
        ],
        // moddleExtensions: {
        //   camunda: camundaModdleDescriptors
        // }
      })
      this.createNewDiagram()
    },
    async createNewDiagram () {
      let bpmnXML = Diagram
      try {
        await this.bpmnModeler.importXML(bpmnXML)
        // ...
      } catch (err) {
        // err...
      }
    }
  }
}
</script>
<style scoped>
.containers {
  position: absolute;
  background-color: #ffffff;
  width: 100%;
  height: 100%;
}
.canvas,
.modeler {
  width: 100%;
  height: 100%;
}
.panel {
  position: absolute;
  right: 0;
  top: 0;
  width: 300px;
}
</style>