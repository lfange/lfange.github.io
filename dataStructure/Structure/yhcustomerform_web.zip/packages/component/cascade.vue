<template>
  <div>
    <div v-for="(item, index) in params.list" :key="index">
      <el-checkbox v-model="outer" :label="params.title"></el-checkbox>
      <el-checkbox-group v-model="list" class="innerGroup">
        <el-checkbox v-for="(item,index) in params.list" :key="index" :label="item.key">{{item.value}}</el-checkbox>
      </el-checkbox-group>
    </div>
  </div>
</template>

<script>
export default {
  name: "cascade",
  props: ['params'],
  data () {
    return {
      outer: false,
      list: []
    }
  },
  methods: {
    handleDicClear () {

    }
  },
  watch: {
    event (val) {
      try {
        console.log(val)
        this.data.event = eval("(" + val + ")")
      } catch (e) {
        // console.error(e)
      }
    },
  }
}
</script>
<style lang="scss" scoped>
.innerGroup {
  padding-left: 30px;
}
</style>
