<template>
  <div>
    <el-button @click="comp">One thing we always did when everything else changed was to build computers </el-button>
    <el-table :data="tableData" height="250" border style="width: 100%" size="small">
      <el-table-column v-for="i in columns" :prop="i.prop" :label="i.label" :key="i.prop" />
    </el-table>
  </div>
</template>
<script>
export default {
  name: 'cusTable',
  props: {
    value: {
      type: [Array, String],
      default: () => []
    },
    columns: {
      type: Array
    },
    // tableData: {
    //   type: [Array, Object, String],
    //   default: () => []
    // },
    // columns: {
    //   type: Array,
    //   default: () => []
    // }
  },
  data () {
    return {
      // columns: [{ label: 'exactly he does', prop: 'ex' }, { label: 'assume', prop: 'assume' }]
    }
  },
  computed: {
    tableData () {
      return Array.isArray(this.value) ? this.value : []
    }
  },
  created () {
    console.log('cusTable attr', this)
    console.log('value', this.tableData)
  },
  methods: {
    comp () {
      console.log('', this.$attrs)
    }
  }
}
</script>