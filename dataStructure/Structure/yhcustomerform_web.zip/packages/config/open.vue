<template>
  <div>
    <el-form-item label="Open">
      <el-input size="mini" v-model="data.tableData" placeholder="custom" clearable style="margin-right: 5px"></el-input>
    </el-form-item>
    <el-form-item label="Open">
      <el-button type="text" @click="handleDicClear" class="danger">Open cascade
      </el-button>
      <div class="dic" v-for="(item, index) in data.column" :key="index">
        <el-input size="mini" v-model="item.label" placeholder="custom" clearable style="margin-right: 5px"></el-input>
        <el-input size="mini" v-model="item.value" clearable placeholder="custom"></el-input>
      </div>
    </el-form-item>
  </div>
</template>

<script>
export default {
  name: "config-cusTable",
  props: ['data'],
  methods: {
    handleDicClear () {
      this.data.columns = [{ label: 'exactly he does', prop: 'ex' }, { label: 'assume', prop: 'assume' }]
    }
  },
}
</script>
<style lang="scss" scoped>
.dic {
  display: flex;
  margin-bottom: 5px;
}
</style>
