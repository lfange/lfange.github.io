<template>
  <el-dialog title="提示" :visible.sync="dialogVisible" :close-on-click-modal="false">
    <el-table :data="currentItem" style="width: 100%">
      <el-table-column :prop="propKey['label']" label="当选项为" width="180">
      </el-table-column>
      <el-table-column prop="" label="显示以下控件">
        <template slot-scope="{row}">
          <el-select v-model="row.showProp" placeholder="请选择" clearable @change="val => selectComp(row, val)">
            <el-option v-for="item in allColum" :key="item.prop" :label="item.label" :value="item.prop">
            </el-option>
          </el-select>
        </template>
      </el-table-column>
    </el-table>
    <span slot="footer" class="dialog-footer">
      <el-button @click="dialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    selectColum: {
      type: Object,
      default: () => { }
    }
  },
  data () {
    return {
      // dialogVisible: true
    }
  },
  watch: {
    'dialogVisible' (val) {
      console.log('watch', val)
    }
  },
  computed: {
    'dialogVisible': {
      get () {
        console.log('data', this.$attrs)
        console.log('selectColum', this.selectColum)
        return this.visible
      },
      set (val) {
        this.$emit('update:visible', val)
      }
    },
    'currentItem' () {
      return this.$attrs.data.dicData
    },
    propKey () {
      return this.$attrs.data.props || {}
    },
    allColum () {
      return this.selectColum.column.filter(it => it.prop !== this.$attrs.data.prop)
    }
  },
  created () {
    console.log('dialogVisble', this.dialogVisble)
  },
  methods: {
    selectComp (row, val) {
      console.log('row, item', row, val)
      const { data } = this.$attrs
      row.showProp = val
      // this.allColum.forEach(it => {
      //   if (it.prop === row.showProp) {
      //     console.log('value', it)
      //     it.display = false
      //   }
      // });
      data.change =
        `
        (itemr) => {
          const { value, column } = itemr

          if (this.form[column.prop] === value) {
            const itDic = column.dicData.find(w => w.value === value)
            console.log('itDic', itDic, itDic.showProp)
            if (!itDic) return
            data.column.forEach(it => {
              if (it.prop === itDic.showProp) it.display = true
            })
          } else {
            column.dicData.forEach(w => {
              console.log('w',w)
              if (w.value !== value) {
                data.column.forEach( it => {
                  if (it.prop === w.showProp) it.display = false
                })
              }
            })
          }
          console.log('value',column, value)
          console.log('data', data)
        }
      `
    }
  }
}
</script>