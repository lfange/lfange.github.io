import Config from './config'
import FormDesign from './index.vue'

// -------------------------------------------  自定义组件 ----------------------------------------
import Cascade from './component/cascade.vue'
import cusTable from './component/cusTable.vue'



export default {
  install(Vue) {
    Vue.use(Config)
    Vue.component('Avue' + FormDesign.name, FormDesign);
    Vue.component(Cascade.name, Cascade)
    Vue.component(cusTable.name, cusTable)
  }
}