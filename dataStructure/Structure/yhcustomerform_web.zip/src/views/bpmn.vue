<template>
  <div>
    <Bpmn />
  </div>
</template>
<script>
import Bpmn from '@/component/bpmn.vue'
export default {
  components: {
    Bpmn
  },
}
</script>