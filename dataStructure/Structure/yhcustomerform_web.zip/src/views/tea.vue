<template>
  <div>
    <p style="line-height: 40px;">
      config-eventconfig-event
    </p>
  </div>
</template>

<script>
export default {
  name: 'config-tea',
  props: {
    value: {
      type: [String, Number],
      default: ''
    }
  },
  data () {
    return {
    }
  },
  watch: {

  },
  computed: {
    seleted: {
      get () {
        return this.value
      },
      set (val) {
        this.$emit('input', val)
      }
    }
  }
}
</script>

<style>
</style>