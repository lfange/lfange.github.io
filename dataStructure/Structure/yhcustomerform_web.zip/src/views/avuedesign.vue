<template>
  <div>
    <avue-form-design style="height: 100vh" :options="options" @submit="handleSubmit" :custom-fields="customFields" :default-values="defaultValues"></avue-form-design>
  </div>
</template>
<script>
import tea from './tea.vue'
export default {
  data () {
    return {
      customFields: [
        {
          title: '分割线',
          component: 'el-divider',//ele分割线
          span: 24,
          icon: 'el-icon-eleme',
          tips: '看我：自定义属性怎么用？',
          labelWidth: '0px',
          params: {
            html: '<h3 style="color:red">分割线标题</h3>',
            contentPosition: "left",
          }
        },
        {
          title: '警告',
          component: 'el-alert',
          labelWidth: '0px',
          span: 24,
          icon: 'el-icon-warning',
          tips: '看我：自定义事件怎么用？',
          params: {
            title: '警告警告警告警告',
            type: 'success'
          },
          event: {
            close: () => {
              console.log('alert关闭事件')
            }
          }
        },
        {
          title: '茶',
          component: 'open',//ele分割线
          span: 24,
          icon: 'el-icon-eleme',
          tips: '看我：自定义属性怎么用？',
          labelWidth: '0px',
          custom: true, //自定义配置文件
          params: {
          }
        },
        {
          title: '茶华',
          component: tea,//ele分割线
          span: 24,
          icon: 'el-icon-eleme',
          tips: '看我：自定义属性怎么用？',
          labelWidth: '0px',
          params: {
          }
        },
        {
          title: '多级多选框',
          component: 'cascade',
          labelWidth: '0px',
          span: 24,
          icon: 'el-icon-eleme',
          tips: '123',
          params: {
            title: '主要名称',
            list: [{
              key: 1,
              value: '选项1'
            }, {
              key: 2,
              value: '选项2'
            }, {
              key: 3,
              value: '选项3'
            }]
          },
          event: {
            change: eval(`() => {
              console.log('alert关闭事件')
            }`)
          }
        },
        {
          title: '自定义表格',
          component: 'cusTable',//ele分割线
          span: 24,
          icon: 'el-icon-eleme',
          // tips: '自定义表格',
          labelWidth: '0px',
          custom: true, //自定义配置文件
          columns: []
        },
      ],
      options: {},
      // options: `{
      //   column: [
      //     {
      //       label: '预览查看下方字段联动',
      //       span: 24,
      //       labelPosition: 'top',
      //       labelWidth: 120
      //     },
      //     {
      //       type: 'switch',
      //       label: '控制显隐',
      //       span: 24,
      //       display: false,
      //       value: '0',
      //       dicData: [
      //         {
      //           label: '',
      //           value: '0'
      //         },
      //         {
      //           label: '',
      //           value: '1'
      //         }
      //       ],
      //       prop: '1629695558953_19833',
      //       change: ({ value }) => {
      //                     const input = this.findObject(this.option.column, 'input')
      //                     if (value == 0) {
      //                       input.display = false
      //                     } else {
      //                       input.display = true
      //                     }
      //                   }
      //     },
      //     {
      //       type: 'input',
      //       label: '单行文本',
      //       span: 24,
      //       display: true,
      //       prop: 'input'
      //     },
      //     {
      //       type: 'select',
      //       label: '值改变',
      //       dicData: [
      //         {
      //           label: '一天',
      //           value: '1'
      //         },
      //         {
      //           label: '两天',
      //           value: '2'
      //         },
      //         {
      //           label: '三天',
      //           value: '3'
      //         }
      //       ],
      //       cascaderItem: [],
      //       span: 24,
      //       display: true,
      //       props: {
      //         label: 'label',
      //         value: 'value'
      //       },
      //       prop: '1629695859796_23456',
      //       change: ({ value }) => {
      //                     let text = value
      //                     if (value) {
      //                       text = '请假 ' + value + ' 天'
      //                     }
      //                     this.$set(this.form, 'input2', text)
      //                   }
      //     },
      //     {
      //       type: 'input',
      //       label: '单行文本',
      //       span: 24,
      //       display: true,
      //       prop: 'input2'
      //     },
      //     {
      //       type: 'array',
      //       label: '数组',
      //       span: 24,
      //       display: true,
      //       prop: 'a164603683909495484'
      //     }
      //   ],
      //   labelPosition: 'left',
      //   labelSuffix: '：',
      //   labelWidth: 120,
      //   gutter: 0,
      //   menuBtn: true,
      //   submitBtn: true,
      //   submitText: '提交',
      //   emptyBtn: true,
      //   emptyText: '清空',
      //   menuPosition: 'center'
      // }`,

    }
  },
  methods: {
    handleSubmit (val) {
      this.$message.success("查看控制台")
      console.log(val);
    },
  }
}
</script>