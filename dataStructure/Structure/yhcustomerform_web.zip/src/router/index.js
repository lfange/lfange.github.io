// import Vue from 'vue'
// import Router from 'vue-router'

// console.log('Unkn<router-view>', Router)

// Vue.use(Router)

// export default Router({
//   // history: Router.createWebHashHistory(),
//   routes: [{
//       path: '/avuedesign',
//       name: 'avuedesign',
//       component: () => import('../views/avuedesign.vue')
//     },
//     {
//       path: '/bpmn',
//       name: 'bpmn',
//       component: () => import('../views/bpmn.vue')
//     }
//   ]
// })