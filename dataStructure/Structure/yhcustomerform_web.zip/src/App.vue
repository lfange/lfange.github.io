<template>
  <div id="app">
    <!-- <router-view /> -->
    <Design />
  </div>
</template>

<script>
// import Bpmn from '@/component/bpmn.vue'
import Design from './views/avuedesign.vue'
export default {
  name: 'app',
  components: {
    // Bpmn
    Design
  },
  data () {
    return {
    }
  },
  methods: {
  }
}
</script>
<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  min-height: 100%;
  height: 100%;
}
</style>
