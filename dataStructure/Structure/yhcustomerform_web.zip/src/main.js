import Vue from 'vue'

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI)
import App from './App'
// console.log('VuePress ', router)
import router from './router'

import Avue from '../node_modules/@smallwei/avue';
// import '@smallwei/avue/lib/index.css';

import AvueFormDesign from '../packages/';
import AvueUeditor from 'avue-plugin-ueditor'
Vue.use(Avue)

console.dir(Vue)

console.log('VuePress ', router)

// Vue.use(window.AVUE)
Vue.use(AvueFormDesign)
Vue.use(AvueUeditor)
Vue.config.productionTip = false

process.env.NODE_ENV === "development"

Vue.config.devtools = true

new Vue({
  render: h => h(App),
  // router: router,
  // template: '<App/>',
  // components: {
  //   App
  // }
}).$mount('#app')